package com.kh.secom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecomApplicationTests {

	@Test
	void contextLoads() {
	}

}
