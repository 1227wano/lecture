package com.kh.secom.exception;

public class InvalidParameterException extends RuntimeException{
	
	public InvalidParameterException(String message) {
		super(message);
	}
	
	
}
