package com.kh.busan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusanApplicationTests {

	@Test
	void contextLoads() {
	}

}
