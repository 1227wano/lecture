package com.kh.busan.api;

public class NewGenerationLogin {
	
	// 요청 보낼때
	// 요청 URL에
	// 뭐 요청하는지 보내자
	
	// 행위는 메소드로 구분하자
	// GET ==> 조회
	// POST ==> 생성
	// PUT ==> 수정
	// DELETE ==> 삭제
	
}
