package com.kh.busan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusanApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusanApplication.class, args);
	}

}
